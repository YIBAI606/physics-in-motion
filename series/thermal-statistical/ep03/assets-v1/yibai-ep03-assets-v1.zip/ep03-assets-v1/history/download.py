"""Run on a machine with ordinary Wikimedia access: python download.py"""
from pathlib import Path
import json,urllib.request,hashlib
p=Path(__file__).parent
items=json.loads((p/'sources.json').read_text())
for a in items:
 try:
  req=urllib.request.Request(a['url'],headers={'User-Agent':'YibaiEducationalAssets/1.0'})
  with urllib.request.urlopen(req,timeout=45) as r: data=r.read()
  if not data.startswith(b'\xff\xd8'): raise ValueError('Response is not JPEG')
  (p/a['file']).write_bytes(data)
  a['status']='downloaded';a['sha256']=hashlib.sha256(data).hexdigest();print('OK',a['file'])
 except Exception as e: print('FAILED',a['file'],str(e))
(p/'sources.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
