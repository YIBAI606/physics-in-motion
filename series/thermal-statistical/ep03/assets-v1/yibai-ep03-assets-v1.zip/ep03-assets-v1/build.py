from pathlib import Path
import math,json,shutil,subprocess,csv
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).parent
for d in ['svg','png','history','data']: (P/d).mkdir(exist_ok=True)
BG='#0c1422'; FG='#edf1f5'; MUT='#9aaabc'; COLD='#69b8dc'; WARM='#efb276'
def text(x,y,s,size=36,color=FG): return f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" font-family="Noto Sans CJK SC">{s}</text>'
def rect(x,y,w,h,c,r=0):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{c}"/>'
def line(x,y,X,Y,c=WARM,w=6):return f'<path d="M{x} {y}L{X} {Y}" stroke="{c}" stroke-width="{w}" fill="none"/>'
def arrow(x,y,X,Y,c=WARM):return line(x,y,X,Y,c)+f'<path d="M{X-15} {Y-18}L{X} {Y}L{X+15} {Y-18}" fill="none" stroke="{c}" stroke-width="6"/>'
def save(name,body,title='',transparent=False):
 s=f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080"><title>{title or name}</title>'+('' if transparent else rect(0,0,1920,1080,BG))+body+'</svg>'
 (P/'svg'/f'{name}.svg').write_text(s)
def frame(title,sub):return text(100,125,title,56)+text(100,190,sub,27,MUT)
def block(x,y,wood=False):
 c='#916c48' if wood else '#a4b2be'
 s=f'<path d="M{x} {y}l90 -55h510l-90 55Z" fill="{c}"/>'+rect(x,y,510,150,'#684c37' if wood else '#586b7c')+f'<path d="M{x+510} {y}l90 -55v150l-90 55Z" fill="'+('#493c31' if wood else '#334657')+'"/>'
 for k in range(8):s+=line(x+20,y+15+k*17,x+490,y+18+k*17,'#aa8559' if wood else '#8495a2',1)
 return s
def ice(x,y):return f'<path d="M{x} {y}l30 -25h95l-30 25Z" fill="#d9f5ff" fill-opacity=".85"/><path d="M{x} {y}h95v95h-95Z" fill="#9bd9ed" fill-opacity=".7" stroke="#d4f3ff" stroke-width="2"/><path d="M{x+95} {y}l30 -25v95l-30 25Z" fill="#79b8d4" fill-opacity=".7"/>'
save('01-material-comparison',frame('同样的室温，不同的触感','概念示意 · 不代表实验记录')+block(230,580)+block(1090,580,True)+text(410,825,'金属 · 22°C')+text(1270,825,'木材 · 22°C'))
save('02-ice-comparison',frame('同样的冰，放在不同材料上','实验构图示意 · 融化结果需通过真实对照实验确认')+block(230,580)+block(1090,580,True)+ice(440,480)+ice(1300,480)+text(420,825,'金属')+text(1280,825,'木材'))
save('03-ice-cutout',ice(900,450),transparent=True)
save('04-contact-section',frame('接触之后，热量去了哪里？','皮肤 → 室温材料 · 剖面示意')+rect(340,300,1240,240,'#9c725e',24)+rect(340,540,1240,310,'#52697b',12)+text(390,365,'皮肤：初始 32°C')+text(390,795,'材料：初始 22°C')+''.join(arrow(x,460,x,650) for x in [700,960,1220]))
# Model-derived temperature field: skin and material use SAME 2mm spatial scale.
params={'skin':{'e':1200,'alpha':1.1e-7},'metal':{'e':8000,'alpha':1.2e-5},'wood':{'e':450,'alpha':1.3e-7}}
def temp(x,t,mat,skin=False):
 e=params[mat]['e'];tc=(1200*32+e*22)/(1200+e);a=params['skin' if skin else mat]['alpha'];ti=32 if skin else 22
 return ti+(tc-ti)*math.erfc(x/(2*math.sqrt(a*t)))
def col(t):
 f=max(0,min(1,(t-22)/10));a=(66,135,190);b=(239,178,118)
 return '#'+''.join(f'{round(a[i]*(1-f)+b[i]*f):02x}' for i in range(3))
s=frame('温度变化，从接触面向内部展开','理想半无限体模型 · t = 1 s · 两侧各 2 mm · 同一温度色标')
for x,mat,name in [(300,'metal','金属'),(1080,'wood','木材')]:
 s+=text(x,275,name)
 for j in range(400):
  skin=j<200;d=abs(j+0.5-200)/200*.002;s+=rect(x,330+j,530,1.2,col(temp(d,1,mat,skin)))
 s+=line(x,530,x+530,530,FG,2)+text(x+550,410,'皮肤',24)+text(x+550,665,'材料',24)
for j in range(400):s+=rect(650+j,825,1.1,22,col(22+j/399*10))
s+=text(540,845,'22°C',24)+text(1070,845,'32°C',24)
save('05-temperature-field',s)
s=frame('皮肤内部同一深度，温度怎样变化？','教学参数 · 深度 0.15 mm · 不是界面温度，也不是实测数据')
x0,y0=260,820;w,h=1380,490
s+=line(x0,300,x0,y0,MUT,2)+line(x0,y0,x0+w,y0,MUT,2)
for T in [24,26,28,30,32]:
 y=y0-(T-22)/10*h;s+=line(x0,y,x0+w,y,'#233348',1)+text(185,y+9,str(T),25)
for t in [0,1,2,3,4,5]:s+=text(x0+t/5*w-8,865,str(t),25)
s+=text(1580,910,'时间 / s',25)+text(130,285,'°C',25)
rows=[]
for mat,c,label in [('metal',COLD,'接触金属'),('wood',WARM,'接触木材')]:
 pts=[]
 for j in range(501):
  t=j/100;T=32 if t==0 else temp(.00015,t,mat,True);pts.append(f'{x0+t/5*w},{y0-(T-22)/10*h}');rows.append([mat,t,T])
 s+=f'<polyline points="{" ".join(pts)}" fill="none" stroke="{c}" stroke-width="6"/>'
 s+=text(1260,350 if mat=='wood' else 745,label,32,c)
save('06-skin-temperature-curves',s)
with (P/'data'/'skin-temperature.csv').open('w') as f:
 wr=csv.writer(f);wr.writerow(['material','time_s','temperature_C']);wr.writerows(rows)
(P/'data'/'model.json').write_text(json.dumps({'parameters':params,'status':'illustrative, not measured','initial_skin_C':32,'initial_material_C':22,'depth_m':.00015,'assumptions':['1D','semi-infinite','constant properties','perfect contact','no perfusion']},indent=2))
save('07-latent-heat',frame('吸收热量，也可以用来融化','纯冰已达熔点 · 近标准大气压 · 相变示意')+ice(430,420)+text(790,470,'Q = mL<tspan baseline-shift="sub" font-size="50">f</tspan>',100)+text(790,590,'L<tspan baseline-shift="sub" font-size="22">f</tspan> ≈ 334 kJ/kg',42)+text(790,720,'融化 1 g 冰，约需 334 J',38)+text(380,790,'0°C · 冰水共存',30))
save('08-effusivity',frame('导热与储热，共同决定接触表现','热感受率 / thermal effusivity')+text(570,475,'e = √(kρc)',118)+text(360,690,'k：导热系数',37,COLD)+text(1090,690,'ρc：体积热容量',37,WARM)+text(510,850,'理想接触温度更接近热感受率较大的一侧',32,MUT))
save('09-heat-direction',frame('方向取决于温度差','同一块室温材料，在两个实验里扮演不同角色')+text(360,340,'手 · 32°C',45)+text(1120,340,'材料 · 22°C',45)+arrow(550,400,550,650)+arrow(1350,400,1350,650)+text(360,750,'材料 · 22°C',45)+text(1140,750,'冰 · 0°C',45)+text(650,870,'热量自发地从高温处传向低温处',32,MUT))
save('10-contact-resistance',frame('表面的一层涂层，也会改变接触','分层结构示意 · 厚度未按比例绘制')+rect(400,300,1120,210,'#9c725e',16)+rect(400,510,1120,65,'#b5b2a0')+rect(400,575,1120,220,'#52697b',16)+text(450,390,'皮肤')+text(450,555,'涂层 / 接触热阻',28,BG)+text(450,690,'金属基底')+text(600,880,'实际表面不一定满足“完美接触”',30,MUT))
save('11-ending-lights','<defs><radialGradient id="g"><stop stop-color="#efbc82" stop-opacity=".8"/><stop offset=".15" stop-color="#efbc82" stop-opacity=".18"/><stop offset="1" stop-color="#efbc82" stop-opacity="0"/></radialGradient></defs><circle cx="640" cy="490" r="230" fill="url(#g)"/><circle cx="1280" cy="490" r="230" fill="url(#g)"/><circle cx="640" cy="490" r="5" fill="#ffe1b5"/><circle cx="1280" cy="490" r="5" fill="#ffe1b5"/>')
save('12-clean-background','')
# Reuse previously authored transparent assets, retain originals.
for f in (Path('/workspace/work/yibai-asset-library')/'objects').glob('*.svg'):shutil.copy(f,P/'svg'/('object-'+f.name))
for f in (P/'svg').glob('*.svg'):
 subprocess.run(['inkscape',str(f),'--export-type=png','--export-filename='+str(P/'png'/(f.stem+'.png'))],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
ims=[]
font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',20)
for f in sorted((P/'png').glob('*.png')):
 tile=Image.new('RGB',(480,310),BG);im=Image.open(f).convert('RGBA');im.thumbnail((480,270));tile.paste(im,((480-im.width)//2,0),im);ImageDraw.Draw(tile).text((14,278),f.stem,font=font,fill='white');ims.append(tile)
sheet=Image.new('RGB',(1440,310*math.ceil(len(ims)/3)),BG)
for i,im in enumerate(ims):sheet.paste(im,((i%3)*480,(i//3)*310))
sheet.save(P/'contact-sheet.jpg',quality=90)
html='<meta charset="utf-8"><title>忆白 EP03 素材库</title><style>body{background:#0c1422;color:#edf1f5;font:18px sans-serif;margin:40px}main{display:grid;grid-template-columns:repeat(2,1fr);gap:24px}img{width:100%}a{color:#69b8dc}</style><h1>忆白 · 第三期素材库</h1><p>科学图均为示意或教学模型，不是实验记录。历史素材下载状态见 history/sources.json。</p><main>'
for f in sorted((P/'png').glob('*.png')):html+=f'<article><img src="png/{f.name}"><p>{f.stem} · <a href="svg/{f.stem}.svg">SVG</a> · <a href="png/{f.name}">PNG</a></p></article>'
(P/'index.html').write_text(html+'</main>')
print('Created',len(ims),'image pairs')
